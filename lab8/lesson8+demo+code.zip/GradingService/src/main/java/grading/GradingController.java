package grading;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GradingController {
    @RequestMapping("/grades/{studentid}/{courseid}")
    public String getGrade(@PathVariable("studentid") String studentId,
                           @PathVariable("courseid") String courseId) {

        return "A+";
    }
}
