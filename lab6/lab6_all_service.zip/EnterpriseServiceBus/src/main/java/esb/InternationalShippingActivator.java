package esb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class InternationalShippingActivator {

    private static final String INTERNATIONAL_SHIPPING_URL = "http://localhost:8084/orders";

    @Autowired
    private RestTemplate restTemplate;

    public void ship(Order order) {
        System.out.println("INTERNATIONAL shipping: " + order);
        restTemplate.postForLocation(INTERNATIONAL_SHIPPING_URL, order);
    }
}