package com.xuanlocle.lab5.repo;

import com.xuanlocle.lab5.domain.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product, String> {
}
