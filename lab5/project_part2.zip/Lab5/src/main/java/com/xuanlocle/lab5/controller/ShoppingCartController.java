package com.xuanlocle.lab5.controller;

import com.xuanlocle.lab5.domain.ShoppingCart;
import com.xuanlocle.lab5.domain.dto.AddToCartRequest;
import com.xuanlocle.lab5.repo.ShoppingCartRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/shoppingcarts")
public class ShoppingCartController {

    private final ShoppingCartRepository cartRepo;

    public ShoppingCartController(ShoppingCartRepository cartRepo) {
        this.cartRepo = cartRepo;
    }

    @PostMapping("/{cartId}/items")
    public ResponseEntity<ShoppingCart> addToShoppingCart(
            @PathVariable String cartId,
            @RequestBody AddToCartRequest request) {

        ShoppingCart cart = cartRepo.findById(cartId).orElse(new ShoppingCart(cartId));
        cart.addToCart(request.getProductNumber(), request.getQuantity());
        ShoppingCart saved = cartRepo.save(cart);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/{cartId}")
    public ResponseEntity<ShoppingCart> getShoppingCart(@PathVariable String cartId) {
        return cartRepo.findById(cartId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
