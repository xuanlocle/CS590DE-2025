package com.xuanlocle.lab5.domain;// ShoppingCart.java

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Document(collection = "shoppingcarts")
public class ShoppingCart {
    @Id
    private String shoppingcartNumber;
    private List<CartLine> lines = new ArrayList<>();

    public ShoppingCart() {
    }

    public ShoppingCart(String shoppingcartNumber) {
        this.shoppingcartNumber = shoppingcartNumber;
    }

    public void addToCart(String productNumber, int quantity) {
        lines.add(new CartLine(productNumber, quantity));
    }

    public String getShoppingcartNumber() {
        return shoppingcartNumber;
    }

    public void setShoppingcartNumber(String shoppingcartNumber) {
        this.shoppingcartNumber = shoppingcartNumber;
    }

    public List<CartLine> getLines() {
        return lines;
    }

    public void setLines(List<CartLine> lines) {
        this.lines = lines;
    }
}
