package com.xuanlocle.lab5;

import com.xuanlocle.lab5.domain.Product;
import com.xuanlocle.lab5.domain.ShoppingCart;
import com.xuanlocle.lab5.domain.dto.AddToCartRequest;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestClientRunner {

    private static final String BASE_URL = "http://localhost:8080";

    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    CommandLineRunner runClient(RestTemplate restTemplate) {
        return args -> {
            Product newProduct = new Product("P100", "Nice keyboard", 49.99);
            Product created =
                    restTemplate.postForObject(BASE_URL + "/products", newProduct, Product.class);
            System.out.println("Created product: " + created.getProductNumber() + " " + created.getDescription());

            Product fetched =
                    restTemplate.getForObject(BASE_URL + "/products/P100", Product.class);
            System.out.println("Fetched product: " + fetched.getProductNumber()
                    + " price=" + fetched.getPrice());

            String cartId = "CART1";
            AddToCartRequest req = new AddToCartRequest();
            req.setProductNumber("P100");
            req.setQuantity(2);

            ShoppingCart cart =
                    restTemplate.postForObject(
                            BASE_URL + "/shoppingcarts/" + cartId + "/items",
                            req,
                            ShoppingCart.class
                    );
            System.out.println("Cart after add: " + cart.getShoppingcartNumber()
                    + " lines=" + cart.getLines().size());

            ShoppingCart fetchedCart =
                    restTemplate.getForObject(
                            BASE_URL + "/shoppingcarts/" + cartId,
                            ShoppingCart.class
                    );

            System.out.println("Fetched cart: " + fetchedCart.getShoppingcartNumber());
            fetchedCart.getLines().forEach(line ->
                    System.out.println("  product=" + line.getProductNumber()
                            + " qty=" + line.getQuantity())
            );
        };
    }
}
