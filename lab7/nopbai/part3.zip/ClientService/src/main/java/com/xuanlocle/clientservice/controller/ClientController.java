package com.xuanlocle.clientservice.controller;

import com.xuanlocle.clientservice.CartFeignClient;
import com.xuanlocle.clientservice.ProductFeignClient;
import com.xuanlocle.clientservice.domain.AddToCartRequest;
import com.xuanlocle.clientservice.domain.Product;
import com.xuanlocle.clientservice.domain.ShoppingCart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/client")
public class ClientController {

    @Autowired
    private final ProductFeignClient productClient;
    @Autowired
    private final CartFeignClient cartClient;

    public ClientController(ProductFeignClient productClient, CartFeignClient cartClient) {
        this.productClient = productClient;
        this.cartClient = cartClient;
    }

    @PostMapping("/products")
    public ResponseEntity<Product> addProduct(@RequestBody Product product) {
        productClient.addProduct(product);
        return ResponseEntity.ok(product);
    }

    @GetMapping("/products/{productNumber}")
    public ResponseEntity<Product> getProduct(@PathVariable("productNumber") String productNumber) {
        final var product = productClient.getProduct(productNumber);
        return ResponseEntity.ok(product);
    }

    @PostMapping("/shoppingcarts/{cartId}/items")
    public ResponseEntity<ShoppingCart> addToCart(
            @PathVariable String cartId,
            @RequestBody AddToCartRequest request) {
        final var shoppingCart = cartClient.addToShoppingCart(cartId, request);
        return ResponseEntity.ok(shoppingCart);
    }

    @GetMapping("/shoppingcarts/{cartId}")
    public ResponseEntity<ShoppingCart> getCart(@PathVariable String cartId) {
        return ResponseEntity.ok(cartClient.getShoppingCart(cartId));
    }
}