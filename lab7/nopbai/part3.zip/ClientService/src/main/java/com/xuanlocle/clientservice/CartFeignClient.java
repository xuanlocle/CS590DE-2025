package com.xuanlocle.clientservice;

import com.xuanlocle.clientservice.domain.AddToCartRequest;
import com.xuanlocle.clientservice.domain.ShoppingCart;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "shoppingservice", url = "http://localhost:8901")
public interface CartFeignClient {
    @PostMapping("/shoppingcarts/{cartId}/items")
    ShoppingCart addToShoppingCart(
            @PathVariable String cartId,
            @RequestBody AddToCartRequest request);

    @GetMapping("/shoppingcarts/{cartId}")
    ShoppingCart getShoppingCart(@PathVariable String cartId);

}
