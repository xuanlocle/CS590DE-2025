package com.xuanlocle.clientservice;

import com.xuanlocle.clientservice.domain.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "product-service", url = "http://localhost:8900")

public interface ProductFeignClient {
    @PostMapping("/products")
    Product addProduct(@RequestBody Product product);

    @PutMapping("/products/{id}")
    void updatePrice(@PathVariable("id") String id, @RequestParam("price") double price);

    @GetMapping("/products/{productNumber}")
    Product getProduct(@PathVariable("productNumber") String productNumber);

}
