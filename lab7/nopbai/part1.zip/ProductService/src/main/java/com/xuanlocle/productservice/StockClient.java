package com.xuanlocle.productservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "stockClient", url = "http://localhost:8900")
public interface StockClient {

    @GetMapping("/stock/{productNumber}")
    int getStock(@PathVariable int productNumber);
}