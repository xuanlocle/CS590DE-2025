package com.xuanlocle.productservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

    private StockClient stockClient;

    public ProductController(StockClient stockClient) {
        this.stockClient = stockClient;
    }

    @RequestMapping("/product/{productNumber}")
    public Product getProduct(@PathVariable int productNumber) {
        int stock = stockClient.getStock(productNumber);
        return new Product(productNumber, "Sample Product", stock);
    }


    @FeignClient(name = "StockService", url = "http://localhost:8900")
    interface StockClient {
        @GetMapping("/stock/{productNumber}")
        public int getStock(@PathVariable("productNumber") int productNumber);
    }
}