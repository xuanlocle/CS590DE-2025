package com.xuanlocle.productservice;

public record Product(int productNumber, String name, int stock) {

}