package com.xuanlocle.productservice;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

    @Autowired
    private StockClient stockClient;

    @GetMapping("/product/{productNumber}")
    @CircuitBreaker(name = "stockServiceCB", fallbackMethod = "stockFallback")
    public Product getProduct(@PathVariable("productNumber") int productNumber) {
        int stock = stockClient.getStock(productNumber);
        return new Product(productNumber, "Sample Product", stock);
    }

    public Product stockFallback(int productNumber, Throwable ex) {
        return new Product(productNumber, "Sample Product", 0);
    }


    @FeignClient(name = "api-gateway", url = "http://localhost:9000")
//    @FeignClient(name = "stock-service")
    interface StockClient {
        @GetMapping("/stock/{productNumber}")
        public int getStock(@PathVariable("productNumber") int productNumber);
    }
}