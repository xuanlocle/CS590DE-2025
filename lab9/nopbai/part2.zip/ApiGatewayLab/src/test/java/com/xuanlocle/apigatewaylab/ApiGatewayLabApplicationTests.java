package com.xuanlocle.apigatewaylab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayLabApplicationTests {

    @Test
    void contextLoads() {
    }

}
