package com.xuanlocle.speedservice.interstatetrafficsensor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterstateTrafficSensorApplicationTests {

    @Test
    void contextLoads() {
    }

}
