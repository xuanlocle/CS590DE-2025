package com.xuanlocle.speedservice.interstatetrafficsensor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.Random;

@SpringBootApplication
public class TrafficSensorApplication implements CommandLineRunner {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private ObjectMapper objectMapper = new ObjectMapper();
    private Random random = new Random();

    public static void main(String[] args) {
        SpringApplication.run(TrafficSensorApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        String[] licensePlates = {"ABC123", "XYZ789", "DEF456", "GHI012", "JKL345", "MNO678", "PQR901", "STU234"};

        System.out.println("Starting traffic sensor simulation...");

        for (int i = 0; i < 20; i++) {
            String plate = licensePlates[random.nextInt(licensePlates.length)];
            int baseMinute = random.nextInt(60);
            int baseSecond = random.nextInt(60);

            // Camera 1 record
            SensorRecord record1 = new SensorRecord(plate, baseMinute, baseSecond, 1);
            sendRecord("cameratopic1", record1);

            // Camera 2 record - a few seconds later
            // Speed varies: some will be speeding, some won't
            int timeElapsed = random.nextInt(10) + 15; // 15-25 seconds
            int newSecond = baseSecond + timeElapsed;
            int newMinute = baseMinute;
            if (newSecond >= 60) {
                newSecond -= 60;
                newMinute++;
            }

            SensorRecord record2 = new SensorRecord(plate, newMinute, newSecond, 2);
            sendRecord("cameratopic2", record2);

            Thread.sleep(500); // Small delay between car simulations
        }

        System.out.println("Traffic sensor simulation completed");
    }

    private void sendRecord(String topic, SensorRecord record) throws JsonProcessingException {
        String json = objectMapper.writeValueAsString(record);
        kafkaTemplate.send(topic, json);
        System.out.println("Sent to " + topic + ": " + record);
    }
}
