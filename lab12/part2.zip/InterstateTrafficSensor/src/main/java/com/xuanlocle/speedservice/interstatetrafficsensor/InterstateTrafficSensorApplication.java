package com.xuanlocle.speedservice.interstatetrafficsensor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterstateTrafficSensorApplication {

    public static void main(String[] args) {
        SpringApplication.run(InterstateTrafficSensorApplication.class, args);
    }

}
