package com.xuanlocle.speedservice.ownerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwnerServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
