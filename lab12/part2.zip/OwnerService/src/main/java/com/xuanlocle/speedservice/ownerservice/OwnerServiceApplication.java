package com.xuanlocle.speedservice.ownerservice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class OwnerServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OwnerServiceApplication.class, args);
        System.out.println("OwnerService is running and waiting for speeding records...");
    }
}

@Service
class OwnerLookup {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private ObjectMapper objectMapper = new ObjectMapper();
    private Map<String, Owner> ownerDatabase = new HashMap<>();

    public OwnerLookup() {
        // Initialize mock owner database
        ownerDatabase.put("ABC123", new Owner("John Smith", "123 Main St, Fairfield, IA", "641-555-0101"));
        ownerDatabase.put("XYZ789", new Owner("Jane Doe", "456 Oak Ave, Fairfield, IA", "641-555-0102"));
        ownerDatabase.put("DEF456", new Owner("Bob Johnson", "789 Elm St, Fairfield, IA", "641-555-0103"));
        ownerDatabase.put("GHI012", new Owner("Alice Williams", "321 Pine Rd, Fairfield, IA", "641-555-0104"));
        ownerDatabase.put("JKL345", new Owner("Charlie Brown", "654 Maple Dr, Fairfield, IA", "641-555-0105"));
        ownerDatabase.put("MNO678", new Owner("Diana Prince", "987 Cedar Ln, Fairfield, IA", "641-555-0106"));
        ownerDatabase.put("PQR901", new Owner("Ethan Hunt", "147 Birch Ct, Fairfield, IA", "641-555-0107"));
        ownerDatabase.put("STU234", new Owner("Fiona Green", "258 Spruce Way, Fairfield, IA", "641-555-0108"));
    }

    @KafkaListener(topics = {"speedingtopic"})
    public void receiveSpeedingRecord(@Payload String message) throws JsonProcessingException {
        SpeedData speedData = objectMapper.readValue(message, SpeedData.class);
        Owner owner = ownerDatabase.get(speedData.getLicencePlate());

        if (owner == null) {
            owner = new Owner("Unknown", "Unknown", "Unknown");
        }

        System.out.println("License Plate: " + speedData.getLicencePlate() +
                         ", Speed: " + String.format("%.2f", speedData.getSpeed()) + " mph" +
                         ", Owner: " + owner.getName() +
                         ", Address: " + owner.getAddress() +
                         ", Phone: " + owner.getPhone());

        // Send to fee calculation topic
        OwnerSpeedData ownerSpeedData = new OwnerSpeedData(
            speedData.getLicencePlate(),
            speedData.getSpeed(),
            owner
        );
        String json = objectMapper.writeValueAsString(ownerSpeedData);
        kafkaTemplate.send("ownertopic", json);
    }
}
