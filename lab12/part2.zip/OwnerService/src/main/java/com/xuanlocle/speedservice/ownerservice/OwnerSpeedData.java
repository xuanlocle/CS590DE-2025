package com.xuanlocle.speedservice.ownerservice;

public class OwnerSpeedData {
    private String licencePlate;
    private double speed;
    private Owner owner;

    public OwnerSpeedData() {
    }

    public OwnerSpeedData(String licencePlate, double speed, Owner owner) {
        this.licencePlate = licencePlate;
        this.speed = speed;
        this.owner = owner;
    }

    public String getLicencePlate() {
        return licencePlate;
    }

    public void setLicencePlate(String licencePlate) {
        this.licencePlate = licencePlate;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    @Override
    public String toString() {
        return "OwnerSpeedData{" +
                "licencePlate='" + licencePlate + '\'' +
                ", speed=" + String.format("%.2f", speed) + " mph" +
                ", owner=" + owner +
                '}';
    }
}
