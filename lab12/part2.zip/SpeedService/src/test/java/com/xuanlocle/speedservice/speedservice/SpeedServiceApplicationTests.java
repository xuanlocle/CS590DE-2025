package com.xuanlocle.speedservice.speedservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpeedServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
