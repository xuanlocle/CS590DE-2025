package com.xuanlocle.speedservice.speedservice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class SpeedServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpeedServiceApplication.class, args);
        System.out.println("SpeedService is running and waiting for sensor records...");
    }
}

@Service
class SpeedCalculator {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private ObjectMapper objectMapper = new ObjectMapper();
    private Map<String, SensorRecord> camera1Records = new HashMap<>();

    @KafkaListener(topics = {"cameratopic1"})
    public void receiveCamera1(@Payload String message) throws JsonProcessingException {
        SensorRecord record = objectMapper.readValue(message, SensorRecord.class);
        camera1Records.put(record.getLicencePlate(), record);
    }

    @KafkaListener(topics = {"cameratopic2"})
    public void receiveCamera2(@Payload String message) throws JsonProcessingException {
        SensorRecord record2 = objectMapper.readValue(message, SensorRecord.class);
        SensorRecord record1 = camera1Records.get(record2.getLicencePlate());

        if (record1 != null) {
            // Calculate time difference in seconds
            int time1 = record1.getTotalSeconds();
            int time2 = record2.getTotalSeconds();
            int timeDiff = time2 - time1;

            if (timeDiff < 0) {
                timeDiff += 3600; // Handle hour wraparound
            }

            // Calculate speed: 0.5 miles / time in seconds * 3600
            double speed = (0.5 / timeDiff) * 3600;

            System.out.println("License Plate: " + record2.getLicencePlate() +
                             ", Speed: " + String.format("%.2f", speed) + " mph");

            // If speed > 72 mph, send to speeding topic
            if (speed > 72) {
                SpeedData speedData = new SpeedData(record2.getLicencePlate(), speed);
                String json = objectMapper.writeValueAsString(speedData);
                kafkaTemplate.send("speedingtopic", json);
            }

            // Clean up processed record
            camera1Records.remove(record2.getLicencePlate());
        }
    }
}
