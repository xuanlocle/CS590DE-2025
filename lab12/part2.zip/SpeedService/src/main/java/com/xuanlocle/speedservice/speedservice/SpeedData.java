package com.xuanlocle.speedservice.speedservice;

public class SpeedData {
    private String licencePlate;
    private double speed;

    public SpeedData() {
    }

    public SpeedData(String licencePlate, double speed) {
        this.licencePlate = licencePlate;
        this.speed = speed;
    }

    public String getLicencePlate() {
        return licencePlate;
    }

    public void setLicencePlate(String licencePlate) {
        this.licencePlate = licencePlate;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    @Override
    public String toString() {
        return "SpeedData{" +
                "licencePlate='" + licencePlate + '\'' +
                ", speed=" + String.format("%.2f", speed) + " mph" +
                '}';
    }
}
