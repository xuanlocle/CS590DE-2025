package com.xuanlocle.speedservice.feecalculatorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeeCalculatorServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
