package com.xuanlocle.speedservice.feecalculatorservice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@SpringBootApplication
public class FeeCalculatorServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FeeCalculatorServiceApplication.class, args);
        System.out.println("FeeCalculatorService is running and waiting for owner-speed records...");
    }
}

@Service
class FeeCalculator {

    private ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = {"ownertopic"})
    public void calculateFee(@Payload String message) throws JsonProcessingException {
        OwnerSpeedData data = objectMapper.readValue(message, OwnerSpeedData.class);

        double speed = data.getSpeed();
        int fee = 0;

        // Calculate fee based on speed
        if (speed > 90) {
            fee = 125;
        } else if (speed > 82) {
            fee = 80;
        } else if (speed > 77) {
            fee = 45;
        } else if (speed > 72) {
            fee = 25;
        }

        System.out.println("========================================");
        System.out.println("SPEEDING VIOLATION");
        System.out.println("License Plate: " + data.getLicencePlate());
        System.out.println("Speed: " + String.format("%.2f", speed) + " mph");
        System.out.println("Owner Name: " + data.getOwner().getName());
        System.out.println("Owner Address: " + data.getOwner().getAddress());
        System.out.println("Owner Phone: " + data.getOwner().getPhone());
        System.out.println("Fine Amount: $" + fee);
        System.out.println("========================================");
    }
}
