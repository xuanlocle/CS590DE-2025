package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @Autowired
    private final ServiceBClient serviceB;
    @Autowired
    private final ServiceCClient serviceC;

    public Controller(ServiceBClient serviceB, ServiceCClient serviceC) {
        this.serviceB = serviceB;
        this.serviceC = serviceC;
    }

    @GetMapping("/name")
    public String getName() {
        return "Frank Brown";
    }

    @GetMapping("/phone")
    public String employeeContact(
            @RequestHeader("Authorization") String token) {
        return serviceB.phone(token);
    }

    @GetMapping("/salary")
    public String salary(
            @RequestHeader("Authorization") String token) {
        return serviceC.salary(token);
    }

}


@FeignClient(name = "serviceB", url = "http://localhost:8091")
interface ServiceBClient {

    @GetMapping("/phone")
    String phone(@RequestHeader("Authorization") String token);
}

@FeignClient(name = "serviceC", url = "http://localhost:8092")
interface ServiceCClient {

    @GetMapping("/salary")
    String salary(@RequestHeader("Authorization") String token);
}