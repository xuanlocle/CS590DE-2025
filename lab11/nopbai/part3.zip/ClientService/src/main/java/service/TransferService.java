package service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

@Service
class TransferService {

    private final CheckingClient checking;
    private final SavingClient saving;

    public TransferService(CheckingClient checking, SavingClient saving) {
        this.checking = checking;
        this.saving = saving;
    }

    public void transfer(Long checkingId, Long savingId, double amount) {

        try {
            checking.withdraw(checkingId, amount);
            saving.deposit(savingId, amount);

        } catch (Exception e) {
            // Compensation
            checking.deposit(checkingId, amount);
            throw new RuntimeException("Transfer failed, rolled back");
        }
    }
}

@FeignClient(name = "checking", url = "http://localhost:8091")
interface CheckingClient {
    @PostMapping("/checking/{id}/withdraw")
    void withdraw(@PathVariable Long id, @RequestParam double amount);

    @PostMapping("/checking/{id}/deposit")
    void deposit(@PathVariable Long id, @RequestParam double amount);
}

@FeignClient(name = "saving", url = "http://localhost:8092")
interface SavingClient {
    @PostMapping("/saving/{id}/deposit")
    void deposit(@PathVariable Long id, @RequestParam double amount);
}
