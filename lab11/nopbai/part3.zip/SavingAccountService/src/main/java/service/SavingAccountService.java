package service;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class SavingAccountService {

    private final Map<Long, SavingAccount> accounts = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong();

    public SavingAccount createAccount(double initialBalance) {
        Long id = idGenerator.incrementAndGet();
        SavingAccount acc = new SavingAccount(id, initialBalance);
        accounts.put(id, acc);
        return acc;
    }

    public void deposit(Long id, double amount) {
        // 🔥 Simulated failure (REQUIRED by assignment)
        throw new RuntimeException("Simulated error in SavingAccountService");
    }

    public void depositReal(Long id, double amount) {
        SavingAccount acc = getAccount(id);
        acc.deposit(amount);
    }

    public SavingAccount getAccount(Long id) {
        SavingAccount acc = accounts.get(id);
        if (acc == null) {
            throw new RuntimeException("Saving account not found");
        }
        return acc;
    }
}
