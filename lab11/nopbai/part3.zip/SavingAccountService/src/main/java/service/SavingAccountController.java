package service;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/saving")
public class SavingAccountController {

    private final SavingAccountService service;

    public SavingAccountController(SavingAccountService service) {
        this.service = service;
    }

    @PostMapping("/create")
    public SavingAccount create(@RequestParam double balance) {
        return service.createAccount(balance);
    }

    @PostMapping("/{id}/deposit")
    public void deposit(@PathVariable Long id,
                        @RequestParam double amount) {
        service.deposit(id, amount);
    }

    @GetMapping("/{id}")
    public SavingAccount get(@PathVariable Long id) {
        return service.getAccount(id);
    }
}
