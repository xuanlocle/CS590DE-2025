package service;

import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/checking")
public class CheckingAccountController {

	private final CheckingAccountService service;

	public CheckingAccountController(CheckingAccountService service) {
		this.service = service;
	}

	@PostMapping("/create")
	public CheckingAccount create(@RequestParam double balance) {
		return service.createAccount(balance);
	}

	@PostMapping("/{id}/withdraw")
	public void withdraw(@PathVariable Long id,
						 @RequestParam double amount) {
		service.withdraw(id, amount);
	}

	@PostMapping("/{id}/deposit")
	public void deposit(@PathVariable Long id,
						@RequestParam double amount) {
		service.deposit(id, amount);
	}

	@GetMapping("/{id}")
	public CheckingAccount get(@PathVariable Long id) {
		return service.getAccount(id);
	}
}
