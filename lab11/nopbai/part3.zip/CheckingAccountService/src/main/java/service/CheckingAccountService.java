package service;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class CheckingAccountService {

    private final Map<Long, CheckingAccount> accounts = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong();

    public CheckingAccount createAccount(double initialBalance) {
        Long id = idGenerator.incrementAndGet();
        CheckingAccount acc = new CheckingAccount(id, initialBalance);
        accounts.put(id, acc);
        return acc;
    }

    public void withdraw(Long id, double amount) {
        CheckingAccount acc = getAccount(id);
        acc.withdraw(amount);
    }

    public void deposit(Long id, double amount) {
        CheckingAccount acc = getAccount(id);
        acc.deposit(amount);
    }

    public CheckingAccount getAccount(Long id) {
        CheckingAccount acc = accounts.get(id);
        if (acc == null) {
            throw new RuntimeException("Checking account not found");
        }
        return acc;
    }
}
