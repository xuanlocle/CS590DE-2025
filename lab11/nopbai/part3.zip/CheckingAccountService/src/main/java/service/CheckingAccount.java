package service;

public class CheckingAccount {
    private final Long id;
    private double balance;

    public CheckingAccount(Long id, double balance) {
        this.id = id;
        this.balance = balance;
    }

    public Long getId() {
        return id;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (balance < amount) {
            throw new RuntimeException("Insufficient funds");
        }
        balance -= amount;
    }
}
